from django.shortcuts import render
from django.http import HttpResponse
from tablib import Dataset
from .resources import InstagramInfoResource
from .models import InstagramInfo
import csv
import datetime
from qsstats import QuerySetStats
# Create your views here.
def main(request):
    #person_resource = InstagramInfoResource()
    #dataset = Dataset()
    #new_persons =  open("static/followers.csv")
    #
    #imported_data = dataset.load(new_persons.read())
    #result = person_resource.import_data(dataset, dry_run=True)  # Test the data import
    #
    #if not result.has_errors():
    #        person_resource.import_data(dataset, dry_run=False)  # Actually import now
    #        print(result)
    #        print('nice')
    info = InstagramInfo.objects.all().order_by('date')
    l = []
    #d = []
    for i in info:
        l.append([str(i.date), i.count])
    print(l)
    return render(request, 'info/main.html', {
        'info': info,
        'values': l,
    })