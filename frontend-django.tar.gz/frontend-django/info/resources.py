from import_export import resources
from .models import InstagramInfo

class InstagramInfoResource(resources.ModelResource):
    class Meta:
        model = InstagramInfo