from django.contrib import admin
from .models import InstagramInfo
# Register your models here.
admin.site.register(InstagramInfo)