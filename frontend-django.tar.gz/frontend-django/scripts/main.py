import time
import datetime
from pytz import timezone
import os
import django
import requests
import json

def get_count():
    r = requests.get('https://www.instagram.com/receptysfoto/?__a=1')
    parsed_json = (json.loads(r.text))
    count = parsed_json['graphql']['user']['edge_followed_by']['count']
    return count
#  you have to set the correct path to you settings module
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "instainfo.settings.local")
django.setup()

from info.models import InstagramInfo
ins = InstagramInfo
def get_date():
    global cur_day, cur_day_not_formated, cur_day_formated
    cur_day_not_formated = str(datetime.datetime.now().date())
    #print(cur_day_not_formated)
    cur_day_formated = datetime.datetime.strptime(cur_day_not_formated, "%Y-%m-%d")
    cur = str(timezone('Europe/Kiev').localize(cur_day_formated))
    #print(cur, cur_day_not_formated)
    cur_day = cur_day_formated.day
get_date()
old_day = cur_day
while True:
    get_date()
    if old_day != cur_day:
        #print(f'{cur_day_formated.month}-{cur_day_formated.day}' + "\n")
        #print(cur_day)
        x = get_count()
        z = ins.objects.create(date=str(f'{cur_day_formated.year}-{cur_day_formated.month}-{cur_day_formated.day}'), count=x)
        z.save()
        #print(x)
        old_day = cur_day
        continue
    else:
        print('There is no changes')